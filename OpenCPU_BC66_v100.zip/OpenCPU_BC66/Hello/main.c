/*
 * main.c
 *
 *  Created on: 25.10.2018
 *      Author: Georgi Angelov
 */
#include "custom_feature_def.h"
#include "ril.h"
#include "ril_util.h"
#include "ql_stdlib.h"
#include "ql_error.h"
#include "ql_trace.h"
#include "ql_uart.h"
#include "ql_system.h"
#include "ql_timer.h"

void proc_main_task(s32 taskId) {
	ST_MSG msg;
	while (1) {
		Ql_OS_GetMessage(&msg);
		switch (msg.message) {
		case MSG_ID_RIL_READY:
			Ql_RIL_Initialize();
			break;
		}
	}
}
